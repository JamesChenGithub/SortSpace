//
//  VFTextureDrawView.h
//  Texture-Part1-OneStep
//
//  Created by windy on 17/1/6.
//  Copyright © 2017年 windy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VFDrawCubeView : UIView

- (void)update;
- (void)pauseUpdate;

@end
