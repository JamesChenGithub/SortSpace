//
//  AppDelegate.h
//  DrawCube
//
//  Created by windy on 16/12/17.
//  Copyright © 2016年 windy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

