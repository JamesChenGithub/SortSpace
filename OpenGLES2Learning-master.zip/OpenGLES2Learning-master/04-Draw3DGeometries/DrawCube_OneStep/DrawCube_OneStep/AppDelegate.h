//
//  AppDelegate.h
//  DrawCube_OneStep
//
//  Created by windy on 17/1/13.
//  Copyright © 2017年 windy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

