//
//  AppDelegate.h
//  DrawGeometries_Points
//
//  Created by windy on 16/12/5.
//  Copyright © 2016年 windy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

