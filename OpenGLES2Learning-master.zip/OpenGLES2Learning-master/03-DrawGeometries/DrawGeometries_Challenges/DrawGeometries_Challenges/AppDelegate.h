//
//  AppDelegate.h
//  DrawGeometries_Challenges
//
//  Created by windy on 16/12/1.
//  Copyright © 2016年 windy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

