//
//  VFMath.h
//  DrawTriangle_Fix
//
//  Created by windy on 16/11/15.
//  Copyright © 2016年 windy. All rights reserved.
//

//#pragma once

#ifndef VFMath_h
#define VFMath_h

#include "VFMathTypes.h"

#include "VFMatrix.h"
#include "VFVector.h"
#include "VFColor.h"

#endif /* VFMath_h */
