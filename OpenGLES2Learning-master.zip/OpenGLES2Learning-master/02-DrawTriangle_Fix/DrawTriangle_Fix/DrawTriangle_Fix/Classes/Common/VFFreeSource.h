//
//  VFFreeSource.h
//  DrawGeometries_Lines
//
//  Created by windy on 16/11/06.
//  Copyright © 2016年 windy. All rights reserved.
//

#ifndef VFFreeSource_h
#define VFFreeSource_h

@protocol OpenGLESFreeSource <NSObject>

- (void)releaseSource;

@end

#endif /* VFFreeSource_h */
