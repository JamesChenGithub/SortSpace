//
//  AppDelegate.h
//  Texture-Depth-BiuBiuBiu
//
//  Created by Windy on 2017/2/17.
//  Copyright © 2017年 Windy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

