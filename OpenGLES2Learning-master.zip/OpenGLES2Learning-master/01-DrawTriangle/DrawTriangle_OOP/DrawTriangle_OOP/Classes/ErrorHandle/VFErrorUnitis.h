//
//  VFErrorUnitis.h
//  DrawTriangle_OOP
//
//  Created by windy on 16/10/30.
//  Copyright © 2016年 windy. All rights reserved.
//

#ifndef VFErrorUnitis_h
#define VFErrorUnitis_h

typedef NS_ENUM(NSUInteger, VFErrorType) {
    
    VFErrorType_RBOIdentifier = 0,
    VFErrorType_FBOIdentifier,
    
};

#endif /* VFErrorUnitis_h */
