//
//  VFFreeSource.h
//  DrawTriangle_OOP
//
//  Created by windy on 16/10/30.
//  Copyright © 2016年 windy. All rights reserved.
//

#ifndef VFFreeSource_h
#define VFFreeSource_h

@protocol OpenGLESFreeSource <NSObject>

- (void)releaseSource;

@end

#endif /* VFFreeSource_h */
